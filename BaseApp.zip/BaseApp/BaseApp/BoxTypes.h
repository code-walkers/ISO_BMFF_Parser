#ifndef _BOX_TYPES_H_
#define _BOX_TYPES_H_

#define BOX_TYPE_FTYP_MAND (1000)
#define BOX_TYPE_PDIN      (2000)
#define BOX_TYPE_MOOV_MAND (3000)

typedef enum
{
	BOX_TYPE_MVHD  = BOX_TYPE_MOOV + 1,
	BOX_TYPE_TRACK = BOX_TYPE_MOOV + 2
	BOX_TYPE_MOOF  = BOX_TYPE_MOOV + 3
};




#endif /* _BOX_TYPES_H_*/